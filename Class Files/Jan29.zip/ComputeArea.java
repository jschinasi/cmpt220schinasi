public class ComputeArea {
	public static void main(String[] args) {
		// Declare variables
		double r;
		double area;
		
		// Assign the radius
		r = 20;
		
		// Compute the area
		area = 3.14159 * r * r;
		
		// Output the value
		System.out.println("The area of the circle is: " + area);
	}
}